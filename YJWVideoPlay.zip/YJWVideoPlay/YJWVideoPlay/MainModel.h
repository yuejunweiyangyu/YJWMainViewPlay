//
//  MainModel.h
//  YJWVideoPlay
//
//  Created by apple on 2016/11/26.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainModel : NSObject

@property (nonatomic, strong) NSString *activity_id;
@property (nonatomic, strong) NSString *pic;
@property (nonatomic, strong) NSString *title;

@end
