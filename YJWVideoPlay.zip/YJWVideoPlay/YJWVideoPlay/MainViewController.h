//
//  MainViewController.h
//  YJWVideoPlay
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end
