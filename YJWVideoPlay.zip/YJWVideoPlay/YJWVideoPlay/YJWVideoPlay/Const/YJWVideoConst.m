//
//  YJWVideoConst.m
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

/* 视频播放器上边view高度 */
CGFloat const TOP_VIEW_HEIGHT  = 64;

/* 视频播放器下边view高度 */
CGFloat const BOTTOM_VIEW_HEIGHT = 49;


/* 视频播放器上边view返回按钮高度 */
CGFloat const TOP_VIEW_BUTTON_HEIGHT = 30;

/* 视频播放器上边view返回按钮宽度 */
CGFloat const TOP_VIEW_BUTTON_WIDTH = 80;

/* tabbar和bottombar显示时长 */
CGFloat const DISPLAY_TIMEINTERVAL = 0.5;

/* tabbar和bottombar隐藏时长 */
CGFloat const DISPLAY_INTERVAL = 2;

/* 控件距离父视图边距 */
CGFloat const MARGIN_TO_SUPERVIEW = 15;

/* 播放按钮的宽度 */
CGFloat const PLAYBUTTON_WIDTH = 40;

/* 显示时间的高度 */
CGFloat const TIME_LABEL_HEIGHT = 20;

/* 播放按钮未选中 */
NSString *const PLAY_BUTTON_DISSELECTED = @"kr-video-player-play@2x";

/* 播放按钮已选中 */
NSString *const PLAY_BUTTON_SELECTED = @"kr-video-player-pause@2x";

/* slider按钮图片 */
NSString *const SLIDER_IMAGE_NAME = @"kr-video-player-point@2x";

/* 全屏按钮未选中 */
NSString *const FULL_BUTTON_DISSELECTED = @"kr-video-player-fullscreen@2x";

/* 全屏按钮选中 */
NSString *const FULL_BUTTON_SELECTED = @"kr-video-player-shrinkscreen@2x";







