//
//  YJWVideoConst.h
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

/* 视频播放器上边view高度 */
UIKIT_EXTERN CGFloat const TOP_VIEW_HEIGHT;

/* 视频播放器下边view高度 */
UIKIT_EXTERN CGFloat const BOTTOM_VIEW_HEIGHT;

/* 视频播放器上边view返回按钮高度 */
UIKIT_EXTERN CGFloat const TOP_VIEW_BUTTON_HEIGHT;

/* 视频播放器上边view返回按钮宽度 */
UIKIT_EXTERN CGFloat const TOP_VIEW_BUTTON_WIDTH;

/* tabbar和bottombar隐藏时长 */
UIKIT_EXTERN CGFloat const DISPLAY_TIMEINTERVAL;

/* tabbar和bottombar显示时长 */
UIKIT_EXTERN CGFloat const DISPLAY_INTERVAL;

/* 控件距离父视图边距 */
UIKIT_EXTERN CGFloat const MARGIN_TO_SUPERVIEW;

/* 播放按钮的宽度 */
UIKIT_EXTERN CGFloat const PLAYBUTTON_WIDTH;

/* 显示时间的高度 */
UIKIT_EXTERN CGFloat const TIME_LABEL_HEIGHT;

/* 播放按钮未选中 */
UIKIT_EXTERN NSString *const PLAY_BUTTON_DISSELECTED;

/* 播放按钮已选中 */
UIKIT_EXTERN NSString *const PLAY_BUTTON_SELECTED;

/* slider按钮图片 */
UIKIT_EXTERN NSString *const SLIDER_IMAGE_NAME;

/* 全屏按钮未选中 */
UIKIT_EXTERN NSString *const FULL_BUTTON_DISSELECTED;

/* 全屏按钮选中 */
UIKIT_EXTERN NSString *const FULL_BUTTON_SELECTED;















