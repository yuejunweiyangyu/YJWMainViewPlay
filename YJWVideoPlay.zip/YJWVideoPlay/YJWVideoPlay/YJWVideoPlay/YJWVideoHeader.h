//
//  YJWVideoHeader.h
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//


#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "YJWVideoTopView.h"
#import "YJWVideoBottomView.h"
#import "YJWVideoConst.h"
#import "Masonry.h"


