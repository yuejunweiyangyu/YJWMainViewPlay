//
//  YJWVideoTopView.m
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "YJWVideoTopView.h"
#import "YJWVideoConst.h"
#import "Masonry.h"

@interface YJWVideoTopView()

@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIView *backView;

@end

/* 为了计算按钮距离顶部的距离 */
static CGFloat HEIGHT = 6;
@implementation YJWVideoTopView

- (instancetype)init{
    if (self == [super init]) {
        /* 返回按钮 */
        self.backgroundColor = [UIColor clearColor];
        [self addSubViews];
        
    }
    return self;
}
- (void)addSubViews{
    [self addSubview:self.backView];
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.bottom.mas_equalTo(0);
    }];
    [self addSubview:self.backButton];
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(0);
        make.top.mas_offset((TOP_VIEW_BUTTON_HEIGHT - HEIGHT));
        make.width.mas_equalTo(TOP_VIEW_BUTTON_WIDTH);
        make.height.mas_equalTo(TOP_VIEW_BUTTON_HEIGHT);
    }];
    
}
- (void)backToFront{
    if (self.callBack) {
        self.callBack();
    }
}

- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] init];
        _backView.backgroundColor = [UIColor blackColor];
        _backView.alpha = 0.4;
    }
    return _backView;
}

- (UIButton *)backButton{
    if (!_backButton) {
        _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backButton setImage:[UIImage imageNamed:@"mine_arr_left"] forState:UIControlStateNormal];
        [_backButton setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_backButton addTarget:self action:@selector(backToFront) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backButton;
}

@end
