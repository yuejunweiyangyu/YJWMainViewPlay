//
//  YJWVideoBottomView.h
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^playVideoBlock)(UIButton *button);
typedef void(^fullScreenBlock)();

@protocol sliderDelegate <NSObject>

- (void)ValueChanged:(UISlider *)slider;
- (void)TouchBegan:(UISlider *)slider;
- (void)TouchEnded:(UISlider *)slider;

@end

@interface YJWVideoBottomView : UIView
/* slider代理回调 */
@property (nonatomic, assign) id<sliderDelegate> sliderDelegate;
/* 缓存进度条颜色 */
@property (nonatomic, strong) UIColor *progressViewColor;
/* 已经看过的slider颜色 */
@property (nonatomic, strong) UIColor *sliderColor;
/* 进度条 */
@property (nonatomic, strong) UISlider *progressSlider;
/* 缓存进度条 */
@property (nonatomic, strong) UIProgressView *progressView;
/* 播放或暂停 */
@property (nonatomic, strong) UIButton *playOrPurseButton;
/* 显示时间 */
@property (nonatomic, strong) UILabel *timeLabel;
/* 全屏按钮 */
@property (nonatomic, strong) UIButton *fullScreenButton;
/* 全屏按钮回调 */
@property (nonatomic, copy) fullScreenBlock fullScreenBlock;
/* 播放按钮回调 */
@property (nonatomic, copy) playVideoBlock playVideoBlock;

@end
