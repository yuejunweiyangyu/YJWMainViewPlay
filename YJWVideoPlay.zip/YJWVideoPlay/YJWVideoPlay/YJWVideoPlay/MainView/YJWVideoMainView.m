//
//  YJWVideoMainView.m
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "YJWVideoMainView.h"
#import "YJWVideoHeader.h"

@interface YJWVideoMainView()<sliderDelegate>{
    BOOL hideBar;  /* 是否隐藏菜单栏 */
    CGFloat totalTime;  /* 视频总时长 */
    BOOL isFirst;  /* 定时器相关 */
    AVPlayerItem *removeItem; /* 移除监听的item */
    BOOL isPlayFinish; /* 是否播放完毕 */
}

@property (nonatomic, strong) YJWVideoTopView *topView;
@property (nonatomic, strong) YJWVideoBottomView *bottomView;
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerLayer *viewLayer;
@property (nonatomic, strong) AVPlayerItem *playerItem;

@end

@implementation YJWVideoMainView

/* 代码创建 */
- (instancetype)init{
    self = [super init];
    if (self) {
        /* 添加一些子控件 */
        [self addSubViews];
        /* 给view添加点击手势 */
        [self addGesture];
        /* 监听屏幕方向 */
        [self deviceOrientation];
        /* 监听播放状态 */
        [self configPlayStatus];
        
    }
    return self;
}
/* xib创建 */
- (void)awakeFromNib{
    [super awakeFromNib];
    /* 添加一些子控件 */
    [self addSubViews];
    /* 给view添加点击手势 */
    [self addGesture];
    /* 监听屏幕方向 */
    [self deviceOrientation];
    /* 监听播放状态 */
    [self configPlayStatus];
}

#pragma mark =========================子控件定制及回调方法===================================
/* 添加一些子控件 */
- (void)addSubViews{
    [self.layer addSublayer:self.viewLayer];
    __weak typeof(self) weakSelf = self;
    [self addSubview:self.topView];
    [self.topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(TOP_VIEW_HEIGHT);
        make.left.top.right.mas_equalTo(0);
    }];
    /* 点击返回按钮 */
    self.topView.callBack = ^(){
        UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
        /* 横屏 */
        if (orientation == UIDeviceOrientationLandscapeRight) {
            [weakSelf rotateDevice:UIDeviceOrientationPortrait];
            weakSelf.bottomView.fullScreenButton.selected = NO;
        }else{
            /* 竖屏 */
            if (weakSelf.backFront) {
                weakSelf.backFront();
            }
        }
    };
    [self addSubview:self.bottomView];
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(BOTTOM_VIEW_HEIGHT);
        make.left.right.bottom.mas_equalTo(0);
    }];
    /* 点击播放按钮 */
    self.bottomView.playVideoBlock = ^(UIButton *button){
        if (button.selected) {
            [weakSelf.player pause];
            button.selected = NO;
        }else{
            [weakSelf playVideo];
        }
    };
    /* 点击全屏按钮 */
    self.bottomView.fullScreenBlock = ^(){
        [weakSelf fullScreen];
    };
}

#pragma mark   ===========================点击view操作=================================
/* 给view添加点击手势 */
- (void)addGesture{
    UITapGestureRecognizer *touchGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchView)];
    [self addGestureRecognizer:touchGesture];
    [self performSelector:@selector(hideBar) withObject:self afterDelay:DISPLAY_INTERVAL];
}
/* 隐藏菜单按钮 */
- (void)hideBar{
    if (hideBar) {
        return;
    }
    [UIView animateWithDuration:DISPLAY_TIMEINTERVAL animations:^{
        self.topView.alpha = 0;
        self.bottomView.alpha = 0;
    } completion:^(BOOL finished) {
        hideBar = YES;
    }];
}
/* 显示菜单按钮 */
- (void)touchView{
    if (hideBar) {
        [UIView animateWithDuration:DISPLAY_TIMEINTERVAL animations:^{
            self.topView.alpha = 1;
            self.bottomView.alpha = 1;
        } completion:^(BOOL finished) {
            hideBar = NO;
            [self performSelector:@selector(hideBar) withObject:self afterDelay:DISPLAY_INTERVAL];
        }];
    }else{
        [self hideBar];
    }
}
#pragma  mark  ========================监听设备旋转================================
- (void)deviceOrientation{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onDeviceOrientationDidChange)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
}
/// 设备旋转方向改变
- (void)onDeviceOrientationDidChange
{
    UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
    switch (orientation) {
        case UIDeviceOrientationPortrait: {
            [self mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.left.top.right.mas_equalTo(0);
                make.height.mas_equalTo(_viewHeight);
            }];
        }
            break;
        case UIDeviceOrientationLandscapeRight: {
            [self mas_updateConstraints:^(MASConstraintMaker *make) {
                make.left.right.top.bottom.mas_equalTo(0);
            }];
        }
            break;
        default:
            break;
    }
    
}

- (void)fullScreen{
    if (self.bottomView.fullScreenButton.selected) {
        [self rotateDevice:UIDeviceOrientationPortrait];
        self.bottomView.fullScreenButton.selected = NO;
    }else{
        [self rotateDevice:UIDeviceOrientationLandscapeRight];
        self.bottomView.fullScreenButton.selected = YES;
        
    }
}
/* 旋转屏幕 */
- (void)rotateDevice:(UIDeviceOrientation)orient{
    NSNumber *value = [NSNumber numberWithInt:orient];
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
}
#pragma mark    ============================监听播放视频完成================================
- (void)configPlayStatus{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playFinish) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
}

- (void)playFinish{
    self.bottomView.playOrPurseButton.selected = NO;
    isPlayFinish = YES;
}
#pragma mark   =========================传入视频播放地址一些操作===================================
/* 播放器高度 */
- (void)setViewHeight:(CGFloat)viewHeight{
    _viewHeight = viewHeight;
}

/* 传入视频地址 */
- (void)setVideoPlayUrl:(NSString *)videoPlayUrl{
    _videoPlayUrl = videoPlayUrl;
    [self customItem:videoPlayUrl];
    [self getTotalTime];
    [self getCurrentTime];
}
/* 给avplayitem添加监听 */
- (void)customItem:(NSString *)videoUrl{
    AVPlayerItem *item = [[AVPlayerItem alloc] initWithURL:[NSURL URLWithString:videoUrl]];
    self.playerItem = nil;
    removeItem = item;
    [removeItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
    [removeItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    [self.player replaceCurrentItemWithPlayerItem:item];
}
/* 获取视频时长 */
- (void)getTotalTime{
    CMTime duration = self.player.currentItem.asset.duration;
    float seconds = CMTimeGetSeconds(duration);
    totalTime = seconds;
}
/* 获取现在的播放进度 */
- (void)getCurrentTime{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        CMTime currentTime = self.player.currentTime;
        float second = CMTimeGetSeconds(currentTime);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.bottomView.progressSlider.value = 1/totalTime * second;
            self.bottomView.timeLabel.text = [NSString stringWithFormat:@"%@/%@",[self timeFormatted:second],[self timeFormatted:totalTime]];
        });
    });
}
/* 将秒转化为时间 */
- (NSString *)timeFormatted:(int)totalSeconds
{
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
    int hours = totalSeconds / 3600;
    return [NSString stringWithFormat:@"%02d:%02d:%02d",hours, minutes, seconds];
}
/* 播放视频 */
- (void)playVideo{
    if (isPlayFinish) {
        CMTime currentTime =  CMTimeMake(0, 1);
        [self.player seekToTime:currentTime];
        [self.player play];
        self.bottomView.playOrPurseButton.selected = YES;
        isPlayFinish = NO;
    }else{
        [self.player play];
        self.bottomView.playOrPurseButton.selected = YES;
    }
    
}

#pragma mark     =======================slider一些回调方法=================================
/* 滑块滑动 */
- (void)ValueChanged:(UISlider *)slider{
    CMTime currentTime =  CMTimeMake(totalTime * slider.value, 1);
    [self.player seekToTime:currentTime];
}
/* 点击滑块 */
- (void)TouchBegan:(UISlider *)slider{
    hideBar = YES;
    [self.player pause];
}
/* 结束点击 */
- (void)TouchEnded:(UISlider *)slider{
    [self.player play];
    self.bottomView.playOrPurseButton.selected = YES;
    hideBar = NO;
    [self hideBar];
}


#pragma mark  ==========================kvo缓存进度=============================
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if ([keyPath isEqualToString:@"status"]) {
        if ([removeItem status] == AVPlayerStatusReadyToPlay) {
            [self playVideo];
            [self monitoringPlayback:removeItem];// 监听播放状态
        } else if ([removeItem status] == AVPlayerStatusFailed) {
            NSLog(@"AVPlayerStatusFailed");
        }
    }else{
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSTimeInterval timeInterval = [self availableDuration];// 计算缓冲进度
            CMTime duration = removeItem.duration;
            CGFloat totalDuration = CMTimeGetSeconds(duration);
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.bottomView.progressView setProgress:timeInterval / totalDuration animated:YES];
            });
        });
    }
}
- (NSTimeInterval)availableDuration {
    NSArray *loadedTimeRanges = [[self.player currentItem] loadedTimeRanges];
    CMTimeRange timeRange = [loadedTimeRanges.firstObject CMTimeRangeValue];// 获取缓冲区域
    float startSeconds = CMTimeGetSeconds(timeRange.start);
    float durationSeconds = CMTimeGetSeconds(timeRange.duration);
    NSTimeInterval result = startSeconds + durationSeconds;// 计算缓冲总进度
    return result;
}
- (void)monitoringPlayback:(AVPlayerItem *)playerItem {
    __weak typeof(self) weakSelf = self;
    [self.player addPeriodicTimeObserverForInterval:CMTimeMake(1, 1) queue:NULL usingBlock:^(CMTime time) {
        [weakSelf getCurrentTime];
    }];
}
#pragma mark      ==========================懒加载相关控件==============================


- (AVPlayerItem *)playerItem{
    if (!_playerItem) {
        _playerItem = [AVPlayerItem playerItemWithURL:[NSURL URLWithString:_videoPlayUrl]];
    }
    return _playerItem;
}
/* 播放器视图 */
- (AVPlayerLayer *)viewLayer{
    if (!_viewLayer) {
        _viewLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
        _viewLayer.backgroundColor = [UIColor clearColor].CGColor;
    }
    return _viewLayer;
}
/* 通过item创建 */
- (AVPlayer *)player{
    if (!_player) {
        _player = [[AVPlayer alloc] initWithPlayerItem:self.playerItem];
        
    }
    return _player;
}

/* 创建播放器上边的视图 */
- (YJWVideoTopView *)topView{
    if (!_topView) {
        _topView = [[YJWVideoTopView alloc] init];
        
    }
    return _topView;
}
/* 创建播放器下边的视图 */
- (YJWVideoBottomView *)bottomView{
    if (!_bottomView) {
        _bottomView = [[YJWVideoBottomView alloc] init];
        _bottomView.sliderDelegate = self;
    }
    return _bottomView;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.viewLayer.frame = self.bounds;
}

- (void)dealloc{
    [removeItem removeObserver:self forKeyPath:@"status"];
    [removeItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    [self.viewLayer removeFromSuperlayer];
    removeItem = nil;
    [self.player pause];
    self.player = nil;
}

@end
