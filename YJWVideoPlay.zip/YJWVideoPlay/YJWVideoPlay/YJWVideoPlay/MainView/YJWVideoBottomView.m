//
//  YJWVideoBottomView.m
//  AvPlayer
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "YJWVideoBottomView.h"
#import "YJWVideoConst.h"
#import "Masonry.h"

@interface YJWVideoBottomView()

@property (nonatomic, strong) UIView *backView;

@end

@implementation YJWVideoBottomView
{
    CGFloat imageHight;
    CGFloat selectedImageWidth;
    CGFloat selectedImageHeight;
}

- (instancetype)init{
    if (self == [super init]) {
        self.backgroundColor = [UIColor clearColor];
        [self customViewColor];
        [self addSubViews];
    }
    return self;
}
- (void)customViewColor{
    self.progressViewColor = [UIColor darkGrayColor];
    self.sliderColor = [UIColor redColor];
}
- (void)addSubViews{
    /* 添加阴影 */
    [self addSubview:self.backView];
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.bottom.mas_equalTo(0);
    }];
    /* 播放或暂停按钮 */
    [self addSubview:self.playOrPurseButton];
    [self.playOrPurseButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(0);
        make.centerY.mas_equalTo(self);
        make.width.mas_equalTo(PLAYBUTTON_WIDTH);
        make.height.mas_equalTo(imageHight);
    }];
    /* 缓存进度条 */
    [self addSubview:self.progressView];
    [self.progressView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(PLAYBUTTON_WIDTH);
        make.right.mas_equalTo(- (MARGIN_TO_SUPERVIEW * 2 + selectedImageWidth));
        make.height.mas_equalTo(2);
        make.centerY.mas_equalTo(self);
    }];
    /* 选择播放时间 */
    [self addSubview:self.progressSlider];
    [self.progressSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(PLAYBUTTON_WIDTH);
        make.right.mas_equalTo(- (MARGIN_TO_SUPERVIEW * 2 + selectedImageWidth));
        make.height.mas_equalTo(2);
        make.centerY.mas_equalTo(self);
    }];
    
    /* 已经播放时间 */
    [self addSubview:self.timeLabel];
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(- (MARGIN_TO_SUPERVIEW * 3 + selectedImageWidth));
        make.height.mas_equalTo(TIME_LABEL_HEIGHT);
        make.bottom.mas_equalTo(0);
         
    }];
    /* 是否全屏 */
    [self addSubview:self.fullScreenButton];
    [self.fullScreenButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(0);
        make.width.mas_equalTo(selectedImageWidth + MARGIN_TO_SUPERVIEW);
        make.height.mas_equalTo(selectedImageHeight);
        make.centerY.mas_equalTo(self);
    }];
}
- (void)playVideo:(UIButton *)button{
    if (self.playVideoBlock) {
        self.playVideoBlock(button);
    }
}

- (void)fullScreen{
    if (self.fullScreenBlock) {
        self.fullScreenBlock();
    }
}
- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] init];
        _backView.backgroundColor = [UIColor blackColor];
        _backView.alpha = 0.4;
    }
    return _backView;
}
- (void)progressSliderValueChanged:(UISlider *)slider{
    if (self.sliderDelegate && [self.sliderDelegate respondsToSelector:@selector(ValueChanged:)]) {
        [self.sliderDelegate ValueChanged:slider];
    }
}
- (void)progressSliderTouchBegan:(UISlider *)slider{
    if (self.sliderDelegate && [self.sliderDelegate respondsToSelector:@selector(TouchBegan:)]) {
        [self.sliderDelegate TouchBegan:slider];
    }
}
- (void)progressSliderTouchEnded:(UISlider *)slider{
    if (self.sliderDelegate && [self.sliderDelegate respondsToSelector:@selector(TouchEnded:)]) {
        [self.sliderDelegate TouchEnded:slider];
    }
}
/* 播放或暂停按钮 */
- (UIButton *)playOrPurseButton{
    if (!_playOrPurseButton) {
        _playOrPurseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:PLAY_BUTTON_DISSELECTED];
        CGFloat imageHeight = image.size.height;
        imageHight = imageHeight;
        [_playOrPurseButton setImage:image forState:UIControlStateNormal];
        UIImage *seletedImage = [UIImage imageNamed:PLAY_BUTTON_SELECTED];
        [_playOrPurseButton setImage:seletedImage forState:UIControlStateSelected];
        [_playOrPurseButton addTarget:self action:@selector(playVideo:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playOrPurseButton;
}
/* 选择播放时间 */
- (UISlider *)progressSlider{
    if (!_progressSlider) {
        _progressSlider = [[UISlider alloc] init];
        UIImage *image = [UIImage imageNamed:SLIDER_IMAGE_NAME];
        [_progressSlider setThumbImage:image forState:UIControlStateNormal];
        _progressSlider.minimumTrackTintColor = self.sliderColor;
        _progressSlider.maximumTrackTintColor = [UIColor clearColor];
        [_progressSlider addTarget:self action:@selector(progressSliderValueChanged:) forControlEvents:UIControlEventValueChanged];
        [_progressSlider addTarget:self action:@selector(progressSliderTouchBegan:) forControlEvents:UIControlEventTouchDown];
        [_progressSlider addTarget:self action:@selector(progressSliderTouchEnded:) forControlEvents:UIControlEventTouchUpInside];
        [_progressSlider addTarget:self action:@selector(progressSliderTouchEnded:) forControlEvents:UIControlEventTouchUpOutside];
        [_progressSlider addTarget:self action:@selector(progressSliderTouchEnded:) forControlEvents:UIControlEventTouchCancel];
    }
    return _progressSlider;
}
/* 缓存进度条 */
- (UIProgressView *)progressView{
    if (!_progressView) {
        _progressView = [[UIProgressView alloc] init];
        _progressView.progressTintColor = self.progressViewColor;
    }
    return _progressView;
}
/* 已经播放时间 */
- (UILabel *)timeLabel{
    if (!_timeLabel) {
        /* 这里调整显示时间的控件 */
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textColor = [UIColor whiteColor];
        _timeLabel.font = [UIFont systemFontOfSize:14];
        _timeLabel.textAlignment = NSTextAlignmentRight;
    }
    return _timeLabel;
}
/* 是否全屏 */
- (UIButton *)fullScreenButton{
    if (!_fullScreenButton) {
        _fullScreenButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage imageNamed:FULL_BUTTON_DISSELECTED];
        CGFloat imageWidth = image.size.width;
        selectedImageWidth = imageWidth;
        CGFloat imageHeight = image.size.height;
        selectedImageHeight = imageHeight;
        [_fullScreenButton setImage:image forState:UIControlStateNormal];
        UIImage *selectedImage = [UIImage imageNamed:FULL_BUTTON_SELECTED];
        [_fullScreenButton setImage:selectedImage forState:UIControlStateSelected];
        [_fullScreenButton addTarget:self action:@selector(fullScreen) forControlEvents:UIControlEventTouchUpInside];
    }
    return _fullScreenButton;
}
@end
