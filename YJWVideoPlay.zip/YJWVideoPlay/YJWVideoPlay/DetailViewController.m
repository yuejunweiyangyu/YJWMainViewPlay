//
//  DetailViewController.m
//  YJWVideoPlay
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "DetailViewController.h"
#import "YJWVideoMainView.h"
#import "Masonry.h"

@interface DetailViewController ()
@property (nonatomic, strong) YJWVideoMainView *videoView;
@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.title = self.name;
    [self addsubView];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}
- (void)addsubView{
    [self.view addSubview:self.videoView];
    [self.videoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(200);
        make.left.right.mas_equalTo(0);
        make.top.mas_equalTo(0);
    }];
    self.videoView.viewHeight = 200;
    self.videoView.videoPlayUrl = self.videoUrl;
}

- (YJWVideoMainView *)videoView{
    if (!_videoView) {
        _videoView = [[YJWVideoMainView alloc] init];
        __weak typeof(self) weakSelf = self;
        _videoView.backFront = ^(){
            [weakSelf.navigationController popViewControllerAnimated:YES];
        };
        _videoView.backgroundColor = [UIColor blackColor];
    }
    return _videoView;
}

@end
