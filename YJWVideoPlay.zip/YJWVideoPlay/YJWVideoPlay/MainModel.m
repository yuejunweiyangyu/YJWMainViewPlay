//
//  MainModel.m
//  YJWVideoPlay
//
//  Created by apple on 2016/11/26.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "MainModel.h"

@implementation MainModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
